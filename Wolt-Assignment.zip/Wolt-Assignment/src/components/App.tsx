import React from "react";
import DeliveryFeeCalculator from "./DeliveryFeeCalculator";

export default function App() {
    return (
        <div>
            <DeliveryFeeCalculator />
        </div>
    );
}
