To run the app:

1. Install Dependencies
   Npm install
2. Run the app
   Npm run dev

Testing:
npm run test
The app is not fully tested, however, there are a few tests so you can have a look at my testing abilities.

I can not say that i am satisfied with the UI/UX, given more time i would have done better on that front.

Given more time i would have liked to write more tests, improve the UI/UX and make the app responsive.

If something does not work, please contact me @ sebastian.mosneagu1@gmail.com
Thank you for the fun Challange.
